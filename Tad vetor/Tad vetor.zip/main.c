#include <stdio.h>
#include "tad_vetor.h"

int main() {
    

    return 0;
}