#include "tad_teste.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

struct teste {
    char TestName[200];
    int total;
    int passaram;
    int falharam;
};

Teste* teste_criar(char* descricao) {
    Teste* t = (Teste*) malloc(sizeof(Teste));
    strcpy(t->TestName, descricao);
    t->total = 0;
    t->passaram = 0;
    t->falharam = 0;
    return t;
}

void teste_verificar(Teste* t, int condicao, char *mensagem) {
    t->total++;
    if(condicao == 1) {
        printf("\n[OK] %s", mensagem);
        t->passaram++;
    }
    else {
        t->falharam++;
        printf("\nErro: %s", mensagem);
    }
}

void teste_relatorio(Teste* t) {
    printf("\n----------------------------------------------------");
    printf("\n%s",t->TestName);
    printf("\n----------------------------------------------------");
    printf("\nTotal    = %d", t->total);
    printf("\nPassaram = %d", t->passaram);
    printf("\nFalharam = %d", t->falharam);

}

void teste_desalocar(Teste** t) {
    free(*t);
    *t = NULL;
}